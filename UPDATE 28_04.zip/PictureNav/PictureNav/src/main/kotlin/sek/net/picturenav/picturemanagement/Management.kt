package sek.net.picturenav.picturemanagement

import org.slf4j.LoggerFactory
import org.springframework.scheduling.annotation.Scheduled
import org.springframework.stereotype.Component
import sek.net.picturenav.directorydata.PictureService

@Component
class Management (val pictureService: PictureService){
    companion object {
        val log = LoggerFactory.getLogger(this::class.java)
    }
    @Scheduled(fixedRate = 50000)
    fun runManagement() {
        log.info("EMPEZAMOS A PROCESAR IMAGENES")
        pictureService.processpictures()

    }
}