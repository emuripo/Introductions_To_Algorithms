package sek.net.picturenav.sqldata

import javax.persistence.*

@Entity
@Table(name = "fotosalumno")

class PicturesAlumno(
   @Id
   val codalu: String,
   val foto: String,
   val fchmod: String
)