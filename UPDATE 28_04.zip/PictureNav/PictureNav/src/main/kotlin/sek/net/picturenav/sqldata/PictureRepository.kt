package sek.net.picturenav.sqldata

import org.springframework.data.jpa.repository.Modifying
import org.springframework.data.jpa.repository.Query
import org.springframework.data.repository.CrudRepository
import org.springframework.data.repository.query.Param
import org.springframework.stereotype.Repository

@Repository
interface PictureRepository : CrudRepository<PicturesAlumno, String> {
    //funcion para select
    fun findByCodalu(codalu: String): Set<PicturesAlumno>

    @Modifying
    @Query("update PicturesAlumno pa set pa.foto=:foto, pa.fchmod=:fchmod where pa.codalu=:codalu")
    fun updatePicture(
        @Param("foto") foto: String,
        @Param("fchmod") fchmod: String,
        @Param("codalu") codalu: String
    )
}