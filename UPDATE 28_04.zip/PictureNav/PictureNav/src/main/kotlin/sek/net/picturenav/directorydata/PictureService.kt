package sek.net.picturenav.directorydata


import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import sek.net.picturenav.sqldata.PictureRepository
import sek.net.picturenav.sqldata.PicturesAlumno
import java.io.File
import java.io.InputStream
import java.nio.file.Files
import java.text.SimpleDateFormat
import java.util.*
import org.springframework.transaction.annotation.Transactional



@Service
@Transactional
class PictureService(val log: Logger, val pictureRepository: PictureRepository) {
   @Synchronized
   fun processpictures() {
      File("\\Users\\sivi_\\Downloads\\PictureNav\\PictureNav\\src\\main\\pictures").walk().forEach {
         if (!Files.isDirectory(it.toPath())) {
            if (processpicture(it)) {
                //Files.delete(it.toPath())
            }
         }
      }
   }

   private fun processpicture(file: File): Boolean {
      var pro: Boolean
      val ins: InputStream = file.inputStream()
      val fotobyte: ByteArray = ins.readBytes()
      val fotoString = Base64.getEncoder().encodeToString(fotobyte)

      val codalu: String = getcodalupath(file.toString())
      val date: Date = Calendar.getInstance().time
      return try {
         pro = if (pictureRepository.findByCodalu(codalu).isEmpty()) {
            pictureRepository.save(
               PicturesAlumno(codalu, fotoString, toDateString(date))
            )
            true
         } else {
            pictureRepository.updatePicture(fotoString, toDateString(date), codalu)
            true
         }
         pro
      } catch (e: Exception) {
         log.error("Ha ocurrido un problema  al procesar la imagen", e)
         false
      }


   }

   private fun getcodalupath(path: String): String = path.split("\\").get(9).split(".").get(0)

   private fun toDateString(date: Date?): String {
      val log = LoggerFactory.getLogger(this::class.java)
      val format = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
      return if (date != null) {
         format.format(date)
      } else {
         ""
      }
   }
}
